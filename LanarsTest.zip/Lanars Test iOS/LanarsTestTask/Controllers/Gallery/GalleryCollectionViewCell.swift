//
//  GalleryCollectionViewCell.swift
//  LanarsTestTask
//
//  Created by Yaroslav Shepilov on 09.03.2022.
//

import UIKit

class GalleryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var mainPhotoView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        mainPhotoView.contentMode = .scaleAspectFit
    }
}
